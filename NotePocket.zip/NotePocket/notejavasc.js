document.addEventListener('DOMContentLoaded', function (event) {


    class Note {
        content;
        title;
        date;
        color;


    }

    loadNote();

    let button = document.querySelector('.savenote');
    const clearnote = document.getElementById('clearNote')

    //zapisywanie notatek do localStorage 
    button.addEventListener('click', function (e) {
        let note = new Note();
        let colors = document.querySelector('.color');
        note.color = colors.options[colors.selectedIndex].value;
        note.title = document.querySelector('.title').value;
        note.content = document.querySelector('.content').value;
        note.date = new Date();

        let jsonNote = JSON.stringify(note);
        localStorage.setItem(note.title, jsonNote);
        loadNote();
    })



    //Ładowanie zapisanych notatek
    function loadNote() {
        let keys = Object.keys(localStorage);

        for (let i = 0; i < keys.length; i++) {
            let noteJson = localStorage.getItem(keys[i]);
            let note = JSON.parse(noteJson);
            createNote('note' + i, note);
        }
    }

    //Zapisane notatki
    function createNote(id = 'note', note) {
        let box = document.querySelector('.box');
        let code = `<div class="note" id="${id}" style="background-color: ${note.color};">
        <button type="button" class="przypnij">Przypnij</button>
        <form class="formbox">
            <textarea  name="title" class="title" readonly placeholder="Title" readonly>${note.title}</textarea>
            <input type="text" name="date" class="date" readonly value="${note.date}">
            <textarea name="content" class="content"  readonly>${note.content}</textarea>
            
        </form>`;
        box.insertAdjacentHTML('afterbegin', code);
    }
    //Czyszczenie localstroage
    clearnote.addEventListener('click', function () {
        localStorage.clear()
    })

    let all = document.querySelector('.note');

    let przypnij = all.querySelector('.przypnij');

    przypnij.addEventListener('click', getleft);

    //Przypięcie notatki do bocznego panelu
    function getleft(event) {
        let element = event.target.parentNode;
        let sticky = document.querySelector('.leftpanel');

        let note = new Note();
        let colors = document.querySelector('.color');
        note.color = colors.options[colors.selectedIndex].value;
        note.title = document.querySelector('.title').value;
        note.content = document.querySelector('.content').value;
        note.date = new Date();

        let jsonNote = JSON.stringify(note);
        localStorage.setItem('sticky' + element.id, jsonNote);

        sticky.insertAdjacentElement('afterbegin', element);
    }

});
//zmiana tła 
function change1() {
    document.querySelector(".box").style.backgroundColor = "lightblue"
}

function change2() {
    document.querySelector(".box").style.backgroundColor = "yellow"
}

function change3() {
    document.querySelector(".box").style.backgroundColor = "pink"
}
function change4() {
    document.querySelector(".box").style.backgroundColor = "white"
}