

document.addEventListener('DOMContentLoaded', appStart)

const soundy = {
    113: "boom",
    119: "clap",
    101: "hihat",
    114: "kick",
    116: "openhat",
    121: "ride",
    117: "snare",
    105: "tink",
    111: "tom",
}
const chanel1 = []
let chanel2 = []
let chanel3 = []
let chanel4 = []
let isRec = false;
let recstartTime = null;

let ChanelOne = false
let ChanelTwo = false
let ChanelThree = false
let ChanelFour = false


/*
//Odtwarzanie dźwieków z klawiatury
window.addEventListener('keydown', function playSound(ev) {
    const audioDOM = document.querySelector(`audio[data-key="${ev.keyCode}"]`)
    

    
            }
        }
   
})


*/

function appStart() {
    window.addEventListener('keypress', playSound)

    //Przycisk do nagrywania
    document.querySelector('#rec').addEventListener("click", recAudio)
    //Przycisk do odtwarzania dźwięków
    document.querySelector('#play').addEventListener("click", playAudio)

    document.querySelector('#kanal1').addEventListener('click', (e) => {
        ChanelOne = !ChanelOne;
        e.target.innerHTML = ChanelOne ? "Kanal 1" : "Kanal 1";
    });

    document.querySelector('#kanal2').addEventListener('click', (e) => {
        ChanelTwo = !ChanelTwo;
        e.target.innerHTML = ChanelTwo ? "Kanal 2" : "Kanal 2";
    });

    document.querySelector('#kanal3').addEventListener('click', (e) => {
        ChanelThree = !ChanelThree;
        e.target.innerHTML = ChanelThree ? "Kanal 3" : "Kanal 3";
    });

    document.querySelector('#kanal4').addEventListener('click', (e) => {
        ChanelFour = !ChanelFour;
        e.target.innerHTML = ChanelFour ? "Kanal 4" : "Kanal 4";
    });
}
//Czytanie dźwięków zapisanych w tab
function playAudio() {
    chanel1.forEach(sound => {
        setTimeout(() => {
            const audioDOM = document.querySelector(`#${sound.sound}`)
            audioDOM.currentTime = 0
            audioDOM.play()

        }, sound.time);
    })

    chanel2.forEach(sound => {
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
            }
            , sound.time
        )
    },
    )

    chanel3.forEach(sound => {
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
            }
            , sound.time
        )
    },
    )

    chanel4.forEach(sound => {
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
            }
            , sound.time
        )
    }
    )
}

//Funkcaj do nagrywania dźwieków
function recAudio(e) {
    isRec = !isRec
    recstartTime = Date.now()

    e.target.innerHTML = isRec ? 'Zatrzymaj' : 'Nagrywaj'



}

//Czytanie dźwięków z klawaitury
function playSound(e) {

    if (!soundy[e.charCode]) {
        return
    }
    const soundName = soundy[e.charCode]
    audioDOM = document.querySelector(`#${soundName}`)
    audioDOM.currentTime = 0;
    audioDOM.play()
    if (ChanelOne) {
        if (isRec) {
            chanel1.push({
                sound: soundName, time: Date.now() - recstartTime
            });
        }
    }
    if (ChanelTwo) {
        if (isRec) {
            chanel2.push({
                sound: soundName, time: Date.now() - recstartTime
            });
        }
    }

    if (ChanelThree) {
        if (isRec) {
            chanel3.push({
                sound: soundName, time: Date.now() - recstartTime
            });
        }
    }

    if (ChanelFour) {
        if (isRec) {
            chanel4.push({
                sound: soundName, time: Date.now() - recstartTime
            });
        }
    }

}

